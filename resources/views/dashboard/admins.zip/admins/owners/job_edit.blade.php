@extends('dashboard.metronic')
@section('content')

 <!-- BEGIN PAGE HEAD-->
 <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
            <h1> {{$job->ar_company_name}}
            </h1>
        </div> 
    </div>
    <!-- END PAGE HEAD-->
    <!-- BEGIN PAGE BREADCRUMB -->
    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="index.html">الرئيسية</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span class="active">تعديل العمل  </span>
        </li>
    </ul>
    <!-- END PAGE BREADCRUMB -->
    <!-- BEGIN PAGE BASE CONTENT --> 
<div class="row"> 
<div class="col-md-12 ">
    <!-- BEGIN SAMPLE FORM PORTLET-->
    <div class="portlet light bordered">
            <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-social-dribbble font-green hide"></i>
                        <span class="caption-subject font-dark bold uppercase">تعديل الوظيفه للشركه : {{$job->ar_company_name}}</span>
                    </div>
                 </div> 
        <div class="portlet-body form">
            <form class="form-horizontal" role="form" method="POST" action="{{route('jobs.update' , $job->id)}}" autocomplete="off">
                @csrf
                @method('PUT')
                <div class="form-body"> 
                  {{-- <input  type="hidden" name="owner_id" value="{{$owner->id}}"> --}}
                  <div class="form-group">
                  <label class="col-md-3 control-label">الدور الوظيفي</label>
                  <div class="col-md-6">
                  <input list ="role" id="inputState" class="form-control" name="role" value =" {{$job->ar_role}} ">
                 </div>
                  <datalist id="role">   
                    @foreach ($roles as $role)  
                    <option value=" {{(app()->getLocale() == 'ar') ? $role->ar_name : $role->name }}">
                    @endforeach
                  </datalist>
                  </div>
                 <div class="form-group">
                 <label class="col-md-3 control-label">المستوي الوظيفي</label>
                   <div class="col-md-6">
                    <input list ="level" id="inputState" class="form-control" name="level" value=" {{$job->ar_level}} ">
                   </div>
                    <datalist id="level">   
                      @foreach ($levels as $level)  
                      <option value=" {{(app()->getLocale() == 'ar') ? $level->ar_name : $level->name }}">
                      @endforeach
                    </datalist>
                  </div>

                  <div class="form-group">
                    <label class="col-md-3 control-label">الدوله</label>
                    <div class="col-md-6">
                    <input list ="country" id="inputState" class="form-control" name="country" value =" {{$job->ar_country}} ">
                   </div>
                    <datalist id="country">   
                      @foreach ($countries as $country)  
                      <option value=" {{(app()->getLocale() == 'ar') ? $country->ar_name : $country->name }}">
                      @endforeach
                    </datalist>
                  </div>
                  <div class="form-group">
                   <label class="col-md-3 control-label">المدينه</label>
                     <div class="col-md-6">
                      <input list ="city" id="inputState" class="form-control" name="city" value=" {{$job->ar_city}} ">
                     </div>
                      <datalist id="city">   
                        @foreach ($cities as $city)  
                        <option value=" {{(app()->getLocale() == 'ar') ? $city->ar_name : $city->name }}">
                        @endforeach
                      </datalist>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 control-label">التخصص الاساسي</label>
                        <div class="col-md-6">
                            <input list ="special" id="inputState" class="form-control" name="special" value=" {{$job->ar_special}} "  placeholder ="التخصص الاساسي"> 
                            <datalist id="special">
                                @foreach ($specials as $special)   
                                  <option value="{{(app()->getLocale() == 'ar') ? $special->ar_name : $special->name }}" >
                                @endforeach
                            </datalist>
                        </div>
                    </div>

                    <div class ="form-group">
                        <label class="col-md-3 control-label">التخصص الفرعي </label>
                           <div class="col-md-6">
                          <input list ="subspecial" id="inputState" class="form-control" name="sub_special" value=" {{$job->ar_sub_special}} " placeholder ="التخصص الفرعي">
                          </div>
                          <datalist id="subspecial">
                            @foreach ($sub_specials as $special)     
                            <option value=" {{(app()->getLocale() == 'ar') ? $special->ar_name : $special->name }}">
                            @endforeach
                          </datalist>
                    </div>
                    
                      <div class="form-group">
                            <label class="col-md-3 control-label"> سنين الخبرة المطلوبة</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control  " placeholder="مثال: 1 شهر و2 سنة " name="experinse" value="{{$job->yearsOfExper}}">
                             </div>
                        </div>
                    
                        
                        <div class="form-group">
                                <label class="col-md-3 control-label">حالة العمل</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="status">
                                        <option value="" selected disabled>حالة العمل</option>
                                        <option value="Full time">دوام كامل</option>
                                        <option value="Part time">دوام جزئي</option>
                                    </select>
                                </div>
                            </div>
                    
                            <div class="form-group ">
                                    <label class="col-md-3 control-label">الراتب</label>
                                    <div class="col-md-6">
                                        <input type="text" class="form-control  " placeholder="مثال: 2500 - 5000" name="selary" value="{{$job->selary}}">
                                      </div>
                                </div>

                            <div class="form-group">
                                    <label class="col-md-3 control-label">الوصف الوظيفي</label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" rows="3" name="ar_description">{{$job->ar_description}}</textarea>
                                    </div>
                                </div>
                                 <div class="form-group">
                                    <label class="col-md-3 control-label">الوصف الوظيفي باللغة الانجليزية</label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" rows="3" name="description">{{$job->description}}</textarea>
                                    </div>
                                </div>
                                <div class="form-actions">
                                <div class="row">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button type="submit" class="btn green">حفظ</button>
                                        <button type="button" class="btn default">إلغاء</button>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div> 
                </div>
            </div>

            <!-- END PAGE BASE CONTENT -->
                         


@endsection